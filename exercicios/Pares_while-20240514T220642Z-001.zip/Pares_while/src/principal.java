
public class principal {

	public static void main(String[] args) {
		
		int num = 2;
		
		System.out.println("Mostrando os numeros pares entre 1 a 50: ");
		
		while(num <= 50 ) {
			System.out.println(num);
			num = num + 2;
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
